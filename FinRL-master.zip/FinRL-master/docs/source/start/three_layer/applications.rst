:github_url: https://github.com/AI4Finance-Foundation/FinRL

================
3. Applications
================
