:github_url: https://github.com/AI4Finance-Foundation/FinRL

5-Others
========================

This section collects uncategorized notebooks such as those made by community members or for some specific usage.

Notebooks in this section includes:

`FinRL_demo_docker.ipynb <https://github.com/AI4Finance-Foundation/FinRL-Tutorials/blob/master/5-Others/FinRL_demo_docker.ipynb>`_,

`tutorial_env_multistock_cashpenalty.ipynb <https://github.com/AI4Finance-Foundation/FinRL-Tutorials/blob/master/5-Others/tutorial_env_multistock_cashpenalty.ipynb>`_,

`tutorial_multistock_docker.ipynb <https://github.com/AI4Finance-Foundation/FinRL-Tutorials/blob/master/5-Others/tutorial_multistock_docker.ipynb>`_,

`tutorial_multistock_variant_2.ipynb <https://github.com/AI4Finance-Foundation/FinRL-Tutorials/blob/master/5-Others/tutorial_multistock_variant_2.ipynb>`_,

`tutorial_this_works_1_18.ipynb <https://github.com/AI4Finance-Foundation/FinRL-Tutorials/blob/master/5-Others/tutorial_this_works_1_18.ipynb>`_.
