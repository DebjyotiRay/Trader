:github_url: https://github.com/AI4Finance-Foundation/FinRL

Homegrown Example
========================

We will demonstrate few homegrown examples in details, including:

1. stock trading

.. toctree::
   :maxdepth: 2

   stocktrading/1-data


2. portfolio optimization
