from __future__ import annotations

ALPACA_API_KEY = "xxx"
ALPACA_API_SECRET = "xxx"
